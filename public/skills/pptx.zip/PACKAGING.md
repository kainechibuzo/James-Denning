Repackaged for JD from Anthropic's public skills repository
(https://github.com/anthropics/skills, Apache-2.0 as stated by that repository).

This JD starter package contains the skill's instruction and reference text
only. Executable scripts from the upstream skill were intentionally omitted:
the JD platform records package files as inert attachments and never executes,
installs or fetches package content. The SKILL.md frontmatter was completed
with packaging metadata (version, licence identifier, category, tags); the
instruction body is unchanged. Publication still requires an independent
administrator review inside JD.
